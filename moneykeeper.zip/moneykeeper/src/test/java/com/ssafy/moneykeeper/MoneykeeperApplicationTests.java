package com.ssafy.moneykeeper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneykeeperApplicationTests {

	@Test
	void contextLoads() {
	}

}
