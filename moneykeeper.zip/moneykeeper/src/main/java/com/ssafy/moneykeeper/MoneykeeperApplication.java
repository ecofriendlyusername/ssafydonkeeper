package com.ssafy.moneykeeper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoneykeeperApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoneykeeperApplication.class, args);
	}

}
